# Scalar Academy LMS Demo Website

This is a demo website for teaching students how to host a static website using Amazon S3 and CloudFront.

## Project Structure

- `index.html` - The main HTML file for the LMS website
- `styles.css` - CSS styling for the website
- `script.js` - JavaScript for interactive elements

## Hosting Instructions

### Step 1: Create an S3 Bucket

1. Sign in to the AWS Management Console
2. Navigate to S3
3. Create a new bucket with a unique name
4. Uncheck "Block all public access"
5. Enable "Static website hosting" in the bucket properties
6. Set "index.html" as the index document

### Step 2: Upload Website Files

1. Upload all files (index.html, styles.css, script.js) to the S3 bucket
2. Set the permissions to "public read" for each file

### Step 3: Create a CloudFront Distribution

1. Navigate to CloudFront in the AWS Management Console
2. Create a new distribution
3. Select your S3 bucket as the origin
4. Configure the following settings:
   - Origin Domain: Your S3 bucket website endpoint
   - Viewer Protocol Policy: Redirect HTTP to HTTPS
   - Default Root Object: index.html
5. Create the distribution

### Step 4: Access Your Website

Once the CloudFront distribution is deployed (this may take a few minutes), you can access your website using the CloudFront domain name provided.

## Demo Information

- Instructor: Govind Kumar
- Date: 07-May-2025
- Purpose: Demonstrating AWS S3 and CloudFront for static website hosting

## Additional Resources

- [Amazon S3 Documentation](https://docs.aws.amazon.com/AmazonS3/latest/userguide/WebsiteHosting.html)
- [Amazon CloudFront Documentation](https://docs.aws.amazon.com/AmazonCloudFront/latest/DeveloperGuide/Introduction.html)
- [AWS Pricing Calculator](https://calculator.aws/)

## Notes for Instructors

This demo website is designed to showcase:
1. Static website hosting with S3
2. Content delivery with CloudFront
3. Basic website structure and design
4. Responsive design principles

Feel free to modify the content to suit your specific teaching needs.