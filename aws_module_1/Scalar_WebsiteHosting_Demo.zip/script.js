// Wait for the DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Add smooth scrolling for all anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 80, // Offset for fixed header
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // Add active class to nav items on scroll
    const sections = document.querySelectorAll('section');
    const navLinks = document.querySelectorAll('nav ul li a');
    
    window.addEventListener('scroll', () => {
        let current = '';
        
        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.clientHeight;
            
            if (pageYOffset >= sectionTop - 200) {
                current = section.getAttribute('id');
            }
        });
        
        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === `#${current}`) {
                link.classList.add('active');
            }
        });
    });
    
    // Mobile menu toggle functionality (if needed)
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    const navMenu = document.querySelector('nav ul');
    
    if (mobileMenuToggle && navMenu) {
        mobileMenuToggle.addEventListener('click', () => {
            navMenu.classList.toggle('show');
        });
    }
    
    // Add animation to cards on scroll
    const animateOnScroll = () => {
        const cards = document.querySelectorAll('.card, .feature, .testimonial');
        
        cards.forEach(card => {
            const cardTop = card.getBoundingClientRect().top;
            const triggerBottom = window.innerHeight * 0.8;
            
            if (cardTop < triggerBottom) {
                card.classList.add('show');
            }
        });
    };
    
    window.addEventListener('scroll', animateOnScroll);
    animateOnScroll(); // Initial check on page load
    
    // Current year for footer copyright
    const yearElement = document.querySelector('.current-year');
    if (yearElement) {
        yearElement.textContent = new Date().getFullYear();
    }
});
// Function to handle testimonial pagination
function showTestimonialPage(pageNum) {
    const mainTestimonials = document.querySelector('.testimonials .testimonial-grid');
    const moreTestimonials = document.getElementById('more-testimonials');
    const moreTestimonialGrids = moreTestimonials.querySelectorAll('.testimonial-grid');
    const paginationDots = document.querySelectorAll('.pagination-dot');
    
    // Reset active state
    paginationDots.forEach(dot => dot.classList.remove('active'));
    
    // Show selected page
    if (pageNum === 1) {
        mainTestimonials.style.display = 'grid';
        moreTestimonials.style.display = 'none';
        paginationDots[0].classList.add('active');
    } else if (pageNum === 2) {
        mainTestimonials.style.display = 'none';
        moreTestimonials.style.display = 'block';
        moreTestimonialGrids[0].style.display = 'grid';
        moreTestimonialGrids[1].style.display = 'none';
        paginationDots[1].classList.add('active');
    } else if (pageNum === 3) {
        mainTestimonials.style.display = 'none';
        moreTestimonials.style.display = 'block';
        moreTestimonialGrids[0].style.display = 'none';
        moreTestimonialGrids[1].style.display = 'grid';
        paginationDots[2].classList.add('active');
    }
}
// Function to handle code explanation tabs
function showTab(tabId) {
    // Hide all tab contents
    const tabContents = document.querySelectorAll('.tab-content');
    tabContents.forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Remove active class from all tab buttons
    const tabButtons = document.querySelectorAll('.tab-btn');
    tabButtons.forEach(button => {
        button.classList.remove('active');
    });
    
    // Show the selected tab content
    document.getElementById(tabId).classList.add('active');
    
    // Add active class to the clicked button
    const activeButton = document.querySelector(`.tab-btn[onclick="showTab('${tabId}')"]`);
    if (activeButton) {
        activeButton.classList.add('active');
    }
}